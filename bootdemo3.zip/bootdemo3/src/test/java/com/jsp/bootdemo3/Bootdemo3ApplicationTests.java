package com.jsp.bootdemo3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bootdemo3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
