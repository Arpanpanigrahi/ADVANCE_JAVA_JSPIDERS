package com.jsp.bootdemo3.exception;

public class UserNotFoundException extends RuntimeException{
	String message;
	public UserNotFoundException(String msg) {
		this.message=msg;
	}
	public String getMessage() {
		return message;
	}
}
