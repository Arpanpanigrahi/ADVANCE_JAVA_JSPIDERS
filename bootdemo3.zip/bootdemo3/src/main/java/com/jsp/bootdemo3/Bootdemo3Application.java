package com.jsp.bootdemo3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication   // specifying the location of entity classes to spring boot
public class Bootdemo3Application {

	public static void main(String[] args) {
		SpringApplication.run(Bootdemo3Application.class, args);
	}

}
