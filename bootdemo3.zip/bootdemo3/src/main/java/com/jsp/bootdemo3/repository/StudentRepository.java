package com.jsp.bootdemo3.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsp.bootdemo3.dto.Student;

public interface StudentRepository extends JpaRepository<Student, Integer> {
	List<Student> findByName(String name);

	List<Student> findByAgeGreaterThan(int age);

	List<Student> findByAgeLessThan(int age);
	
	Student findByPhno(int phno);
}
