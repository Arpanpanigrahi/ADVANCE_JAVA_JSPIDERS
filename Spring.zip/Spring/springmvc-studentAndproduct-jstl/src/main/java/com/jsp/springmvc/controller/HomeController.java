package com.jsp.springmvc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.jsp.springmvc.dao.ProductDao;
import com.jsp.springmvc.dao.StudentDao;
import com.jsp.springmvc.entities.Product;
import com.jsp.springmvc.entities.Student;

@Controller
public class HomeController {

	@Autowired
	StudentDao studentDao;

	@Autowired
	ProductDao productDao;

	@RequestMapping("/addstudent")
	public ModelAndView addStudent() {
		ModelAndView mav = new ModelAndView("StudentForm");
		Student s = new Student();
		mav.addObject("student", s);
		return mav;
	}

	@RequestMapping("/savestudent")
	public ModelAndView saveStudent(@ModelAttribute("student") Student s) {
		ModelAndView mav = new ModelAndView("Home");
		studentDao.saveStudent(s);
		return mav;
	}

	@RequestMapping("/addproduct")
	public ModelAndView addProduct() {
		ModelAndView mav = new ModelAndView("ProductForm");
		Product p = new Product();
		mav.addObject("product", p);
		return mav;
	}

	@RequestMapping("/saveproduct")
	public ModelAndView saveProduct(@ModelAttribute("product") Product p) {
		ModelAndView mav = new ModelAndView("Home");
		productDao.saveProduct(p);
		return mav;
	}

	@RequestMapping("/viewallproducts")
	public ModelAndView viewallproducts() {
		ModelAndView mav = new ModelAndView("allproducts");
		List<Product> products = productDao.fetchAllProducts();
		mav.addObject("allproducts", products);
		return mav;
	}
}
