package com.jsp.springmvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.jsp.springmvc.dao.ProductDao;

import com.jsp.springmvc.entities.Product;

@Controller
public class ProductController {
	@Autowired
	ProductDao productDao;

	@RequestMapping("/addproduct")
	public ModelAndView addProduct() {
		ModelAndView mav = new ModelAndView("ProductForm");
		Product p = new Product();
		mav.addObject("product", p);
		return mav;
	}

	@RequestMapping("/saveproduct")
	public ModelAndView saveProduct(@ModelAttribute("product") Product p) {
		ModelAndView mav = new ModelAndView("Home");
		productDao.saveProduct(p);
		return mav;
	}
}
