package com.jsp;

import org.springframework.stereotype.Component;

@Component
public class TubeLight {
	public TubeLight() {
		System.out.println("constructor is invoked and object is created");
	}
	public void work() {
		System.out.println("tubelight is working properly");
	}
}
