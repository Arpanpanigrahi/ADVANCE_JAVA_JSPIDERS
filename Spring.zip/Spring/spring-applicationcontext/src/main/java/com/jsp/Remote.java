package com.jsp;

public class Remote {
	public Remote() {
		System.out.println("remote constructor is invoked");
	}
}
