package com.jsp.applicationcontextsetterinjection;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component /*
			 * @Component annotation is used to specify POJO class to the IOC container.
			 * Application context IOC container creates objects of a POJO class only if it
			 * is annotated with component.
			 */
public class Sim {
	private int id;
	private String brand;
	private String network;

	public int getId() {
		return id;
	}

	@Value("1")    //@Value annotation is used to specify values to the properties.
	public void setId(int id) {
		this.id = id;
	}

	public String getBrand() {
		return brand;
	}

	@Value("Jio")
	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getNetwork() {
		return network;
	}

	@Value("5G")
	public void setNetwork(String network) {
		this.network = network;
	}

}
