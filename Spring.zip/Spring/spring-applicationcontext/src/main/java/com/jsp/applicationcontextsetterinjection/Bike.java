package com.jsp.applicationcontextsetterinjection;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Bike {
	private int id;
	private String brand;
	private double price;

	public int getId() {
		return id;
	}

	@Value("1")
	public void setId(int id) {
		this.id = id;
	}

	public String getBrand() {
		return brand;
	}

	@Value("pulsar")
	public void setBrand(String brand) {
		this.brand = brand;
	}

	public double getPrice() {
		return price;
	}

	@Value("1000.00")
	public void setPrice(double price) {
		this.price = price;
	}

}
