package com.jsp.applicationcontextsetterinjection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class BikeDriver {
	public static void main(String[] args) {
		ApplicationContext ac = new ClassPathXmlApplicationContext("MyCore.xml");
		Bike bike = (Bike)ac.getBean("bike");
		System.out.println(bike.getId());
		System.out.println(bike.getBrand());
		System.out.println(bike.getPrice());
		
	}
}
