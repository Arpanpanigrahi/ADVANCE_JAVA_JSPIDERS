package com.jsp.springmvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.jsp.springmvc.dao.StudentDao;
import com.jsp.springmvc.entities.Student;

@Controller
public class HomeController {
	@Autowired
	StudentDao studentDao;

//	 EntityManagerFactory entityManagerFactory; //used to establish connection btw java code and db

	@RequestMapping("/hello")
//	public String m1(HttpServletRequest request, HttpServletResponse response) {
//		int id = Integer.parseInt(request.getParameter("id"));
//		String name = request.getParameter("name");
//		int age = Integer.parseInt(request.getParameter("age"));
//		long mobilenumber = Long.parseLong(request.getParameter("mobilenumber"));

	public String m1(@RequestParam("id") int id, @RequestParam("name") String name, @RequestParam("age") int age,
			@RequestParam("mobilenumber") long mobilenumber) {

		System.out.println(id);
		System.out.println(name);
		System.out.println(age);
		System.out.println(mobilenumber);
		return "index";
	}

	@RequestMapping("/hi")
	public ModelAndView m2() {
		ModelAndView mav = new ModelAndView("index");
		return mav;
	}

	@RequestMapping("/savestudent")
	public ModelAndView saveStudent(@RequestParam("id") int id, @RequestParam("name") String name,
			@RequestParam("age") int age) {
		Student s = new Student();
		s.setId(id);
		s.setName(name);
		s.setAge(age);

		studentDao.saveStudent(s);

		ModelAndView mav = new ModelAndView("StudentForm");
		mav.addObject("msg", "student saved successfully");
		return mav;

	}
}
