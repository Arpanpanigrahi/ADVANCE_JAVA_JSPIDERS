package com.jsp.springmvchelper;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@ComponentScan(basePackages = "com.jsp")

public class Config {
	@Bean
	public InternalResourceViewResolver resolver() {
		InternalResourceViewResolver resource = new InternalResourceViewResolver();
		resource.setPrefix("/"); // specifying the location of our jsp file
		resource.setSuffix(".jsp"); // specifying the location of view technology
		return resource;
	}

	@Bean
	public EntityManagerFactory emf() {
		return Persistence.createEntityManagerFactory("arpan");
	}	

}
