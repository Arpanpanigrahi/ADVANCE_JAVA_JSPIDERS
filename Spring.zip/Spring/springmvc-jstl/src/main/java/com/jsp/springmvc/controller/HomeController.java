package com.jsp.springmvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.jsp.springmvc.dao.StudentDao;
import com.jsp.springmvc.entities.Student;

@Controller
public class HomeController {
	@Autowired
	StudentDao studentDao;

	@RequestMapping("/addstudent")
	public ModelAndView addStudent() {
		ModelAndView mav = new ModelAndView("StudentForm");
		Student s = new Student();
		mav.addObject("student", s);
		return mav;
	}

	@RequestMapping("/savestudent")
	public ModelAndView saveStudent(@ModelAttribute("student") Student s) {
		ModelAndView mav = new ModelAndView("Home");
		studentDao.saveStudent(s);
		return mav;
	}
}
