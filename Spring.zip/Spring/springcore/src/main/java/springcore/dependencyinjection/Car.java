package springcore.dependencyinjection;

public class Car {
	private int id;
	private String brand;
	private double price;
	Engine engine;

	public void carDetails() {
		// TODO Auto-generated method stub
		System.out.println("id " + id);
		System.out.println("brand " + brand);
		System.out.println("price " + price);
		System.out.println("engine " + engine);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public Engine getEngine() {
		return engine;
	}

	public void setEngine(Engine engine) {
		this.engine = engine;
	}

}
