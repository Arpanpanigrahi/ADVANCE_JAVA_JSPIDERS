package springcore.dependencyinjection;

public class Engine {
	private int id;
	private double cc;

	public void engineDetails() {
		// TODO Auto-generated method stub
		System.out.println("id " + id);
		System.out.println("cc " + cc);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getCc() {
		return cc;
	}

	@Override
	public String toString() {
		return "Engine [id=" + id + ", cc=" + cc + "]";
	}

	public void setCc(double cc) {
		this.cc = cc;
	}

}
