package springcore;

public class Enginee {
	public static void main(String[] args) {
		System.out.println("Enginee was constructor was invoked, object of enginee is created");
	}
}