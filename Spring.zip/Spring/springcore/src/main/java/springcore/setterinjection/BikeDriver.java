package springcore.setterinjection;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class BikeDriver {
	public static void main(String[] args) {
		ClassPathResource cpr = new ClassPathResource("core.xml");
		BeanFactory beanFactory = new XmlBeanFactory(cpr);
		
		Bike bike = (Bike)beanFactory.getBean("myBike");
		bike.bikeDetails();
	}
}
