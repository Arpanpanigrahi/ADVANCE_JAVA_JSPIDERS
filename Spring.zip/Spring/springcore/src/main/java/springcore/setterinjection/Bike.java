package springcore.setterinjection;

public class Bike {
	private int id;
	private String brand;
	public String model;
	private double price;
	
	public void bikeDetails() {
		// TODO Auto-generated method stub
		System.out.println("id "+id);
		System.out.println("brand "+brand);
		System.out.println("model "+model);
		System.out.println("price "+price);

	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

}
