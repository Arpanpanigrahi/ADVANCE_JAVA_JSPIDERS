package springcore.constructorinjection;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class CarDriver {
	public static void main(String[] args) {
		ClassPathResource cpr = new ClassPathResource("constructor-injection.xml");
		BeanFactory bf = new XmlBeanFactory(cpr);
		
		Car car = (Car)bf.getBean("myCar");
		System.out.println(car.id);
		System.out.println(car.brand);
		System.out.println(car.price);
	}
}
