package springcore.constructorinjection;

public class Car {
	int id;
	String brand;
	double price;
	
	public Car(int id, String brand, double price) {

		this.id = id;
		this.brand = brand;
		this.price = price;
	}
	
	
}
