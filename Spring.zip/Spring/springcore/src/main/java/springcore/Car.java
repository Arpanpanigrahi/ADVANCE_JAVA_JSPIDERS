package springcore;

public class Car {
	public void car() {
		System.out.println("car constructor was invoked, object of car is created");
	}
	
	public void work() {
		System.out.println("work in progress");
	}

}
