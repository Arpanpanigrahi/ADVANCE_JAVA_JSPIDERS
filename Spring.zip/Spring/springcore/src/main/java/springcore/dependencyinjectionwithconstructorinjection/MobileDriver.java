package springcore.dependencyinjectionwithconstructorinjection;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class MobileDriver {
	public static void main(String[] args) {
		ClassPathResource cpr = new ClassPathResource("constructor-injection.xml");
		BeanFactory bf = new XmlBeanFactory(cpr);
		Mobile mobile = (Mobile) bf.getBean("mymobile");
		System.out.println(mobile.id);
		System.out.println(mobile.brand);
		System.out.println(mobile.model);
		
		Battery battery = mobile.battery;
		System.out.println(battery.id);
		System.out.println(battery.mah);
	}
	
}
