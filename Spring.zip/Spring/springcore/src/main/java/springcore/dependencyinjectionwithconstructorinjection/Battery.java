package springcore.dependencyinjectionwithconstructorinjection;

public class Battery {
	int id;
	int mah;
	public Battery(int id, int mah) {
		
		this.id = id;
		this.mah = mah;
	}
	
}
