package com.jsp.springapplicationcontext.primary;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.jsp.springapplicationcontextcac.Config;

public class BabyDriver {
	public static void main(String[] args) {
		ApplicationContext ac = new AnnotationConfigApplicationContext(Config.class);
		Baby baby = (Baby)ac.getBean("baby");
		baby.eat();
	}
}
