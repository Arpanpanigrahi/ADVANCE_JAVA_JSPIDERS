package com.jsp.springapplicationcontextcac;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

//@ComponentScan(basePackages = "com.jsp.springapplicationcontextcac")
@ComponentScan(basePackages = "com.jsp.springapplicationcontext.primary")
/* 
 * ComponentScan is used to specify the package name of our IOC container.
 * 
 */
public class Config {
	//Pen.java
	
	@Bean("mypen")
	/*
	 * Bean is used to get the bean (object) of a POJO class which is not annotated with component.
	 * We majorly use @Bean to get the objects of inbuilt POJO classes because inbuilt classes are not 
	 * annotated with @Component.
	 */
	public Pen getPen() {
		return new Pen();
		
	}
}
