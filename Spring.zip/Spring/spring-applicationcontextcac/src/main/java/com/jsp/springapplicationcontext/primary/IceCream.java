package com.jsp.springapplicationcontext.primary;

public interface IceCream {
	void eat();
}
