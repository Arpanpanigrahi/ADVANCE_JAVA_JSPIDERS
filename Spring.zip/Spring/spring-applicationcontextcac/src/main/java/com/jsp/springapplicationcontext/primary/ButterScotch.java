package com.jsp.springapplicationcontext.primary;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class ButterScotch implements IceCream{

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("Baby is eating ButterScotch");
	}
	
}
