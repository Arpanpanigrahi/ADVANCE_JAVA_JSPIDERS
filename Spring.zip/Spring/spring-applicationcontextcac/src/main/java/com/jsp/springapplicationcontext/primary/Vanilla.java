package com.jsp.springapplicationcontext.primary;

import org.springframework.stereotype.Component;

@Component
public class Vanilla implements IceCream{

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("Baby eating Vanilla");
		
	}
	
}
