package com.jsp.springapplicationcontextcac;

public class Pen {
	public void write() {
		System.out.println("pen is writing good");
	}
}
