package com.jsp.bootdemo1;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsp.bootdemo1.dto.Product;

public interface ProductRepository extends JpaRepository<Product, Integer> {

}
