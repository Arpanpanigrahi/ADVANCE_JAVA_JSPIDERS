package com.jsp.bootdemo1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.bootdemo1.ProductRepository;
import com.jsp.bootdemo1.dto.Product;

@RestController
public class HomeController {
	
	@Autowired
	ProductRepository repository; 
	
	@PostMapping("/hi")
	public String m1() {
		return "hello world";
	}
	
	@PostMapping("/save")
	public String saveProduct(@RequestBody Product product) {
		repository.save(product);
		return "data saved";
	}
}
