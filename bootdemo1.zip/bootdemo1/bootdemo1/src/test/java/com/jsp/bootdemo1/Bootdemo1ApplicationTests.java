package com.jsp.bootdemo1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bootdemo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
