package com.jsp.driver;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.jsp.entities.Account;
import com.jsp.entities.Person;

public class Test1 {
	public static void main(String[] args) {
		List<Account> list = new ArrayList<Account>();
		Person person = new Person();
		person.setName("Vijay");
		person.setLoc("HSR");
		person.setAge(35);
		
		Account account1 = new Account();
		account1.setName("hdfc");
		account1.setNumber(549876321);
		account1.setIfscCode("1000hdfc");
		
		Account account2 = new Account();
		account2.setName("sbi");
		account2.setNumber(123456789);
		account2.setIfscCode("500sbi");
		
		list.add(account1);
		list.add(account2);
		person.setList(list);
		account1.setPerson(person);
		account2.setPerson(person);
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("simha");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
		entityManager.persist(person);
		entityManager.persist(account1);
		entityManager.persist(account2);
		entityTransaction.commit();
	}
}
