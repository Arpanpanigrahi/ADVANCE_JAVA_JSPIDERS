package com.jsp.driver;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.jsp.entities.Student;
import com.jsp.entities.Subject;

public class Test1 {
	public static void main(String[] args) {
		List<Subject> subjects = new ArrayList<Subject>();
		
		Subject subject1 = new Subject();
		subject1.setName("Core Java");
		subject1.setDuration(90);
		subject1.setTrainerName("Raveesh");
		
		Subject subject2 = new Subject();
		subject2.setName("SQL");
		subject2.setDuration(30);
		subject2.setTrainerName("Greeshma");
		
		subjects.add(subject1);
		subjects.add(subject2);
		
		Student student = new Student();
		student.setName("Arpan");
		student.setAddress("Mumbai");
		student.setMarks(78);
		student.setList(subjects);
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("simha");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		
		em.persist(student);
		em.persist(subject1);
		em.persist(subject2);
		
		et.commit();
	}
}
