package compositePrimaryKey;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class SaveEmp {
	public static void main(String[] args) {
		CompositeForEmp compositeForEmp = new CompositeForEmp(101, "iuytr");
		Employee emp = new Employee(compositeForEmp, "Bangalore", 54452);
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("simha");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
		entityManager.persist(emp);
		entityTransaction.commit();
	}
}
