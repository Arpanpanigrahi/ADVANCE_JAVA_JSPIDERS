package compositePrimaryKey;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class SaveStudent {
	public static void main(String[] args) {
		Student student = new Student();
		student.setId(103);
		student.setName("Arpan");
		student.setLoc("BOM");
		student.setMarks(85);
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("simha");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
		entityManager.persist(student);
		entityTransaction.commit();
	}
}
