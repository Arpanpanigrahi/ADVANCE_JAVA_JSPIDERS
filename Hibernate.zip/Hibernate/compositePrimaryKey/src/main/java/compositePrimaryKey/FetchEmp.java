package compositePrimaryKey;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class FetchEmp {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("simha");
		EntityManager em = emf.createEntityManager();
		Employee e = em.find(Employee.class, new CompositeForEmp(101, "Arpan"));
		System.out.println(e);

	}

}