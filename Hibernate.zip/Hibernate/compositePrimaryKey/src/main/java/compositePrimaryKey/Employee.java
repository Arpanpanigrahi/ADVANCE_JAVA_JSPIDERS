package compositePrimaryKey;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Entity
public class Employee {
	@EmbeddedId
	private CompositeForEmp compositeForEmp;
	private String loc;
	private int sal;

	public CompositeForEmp getCompositeForEmp() {
		return compositeForEmp;
	}

	public void setCompositeForEmp(CompositeForEmp compositeForEmp) {
		this.compositeForEmp = compositeForEmp;
	}

	public String getLoc() {
		return loc;
	}

	public void setLoc(String loc) {
		this.loc = loc;
	}

	public int getSal() {
		return sal;
	}

	public void setSal(int sal) {
		this.sal = sal;
	}

	public Employee() {

	}

	public Employee(CompositeForEmp compositeForEmp, String loc, int sal) {
		super();
		this.compositeForEmp = compositeForEmp;
		this.loc = loc;
		this.sal = sal;
	}

}
