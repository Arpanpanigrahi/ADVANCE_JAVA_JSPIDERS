package com.jsp.driver;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.jsp.entities.Account;
import com.jsp.entities.Person;

public class Test1 {
	public static void main(String[] args) {
		List<Account> list = new ArrayList<Account>();
		
		Account account1 = new Account();
		account1.setBankName("HDFC");
		account1.setAddress("Marathahalli");
		account1.setAcNumber(321654987);
		
		Account account2 = new Account();
		account2.setBankName("AXIS");
		account2.setAddress("Marathahalli");
		account2.setAcNumber(123456789);
		
		Account account3 = new Account();
		account3.setBankName("SBI");
		account3.setAddress("HSR LAYOUT");
		account3.setAcNumber(753198246);
		
		list.add(account1);
		list.add(account2);
		list.add(account3);
		
		Person person = new Person();
		person.setName("VIJAY");
		person.setLoc("BANGALORE");
		person.setAge(34);
		person.setAccounts(list);
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("simha");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
		entityManager.persist(account1);
		entityManager.persist(account2);
		entityManager.persist(account3);
		entityManager.persist(person);
		entityTransaction.commit();
	}
}
