package com.jsp.driver;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.jsp.entities.Account;
import com.jsp.entities.Person;

public class Test1 {
	public static void main(String[] args) {
		Person person = new Person();
		person.setName("Arpan");
		person.setAge(23);
		person.setLoc("Bangalore");
		
		Account account1 = new Account();
		account1.setBankName("AXIS");
		account1.setNumber(123456789);
		account1.setPerson(person);
		
		Account account2 = new Account();
		account2.setBankName("HDFC");
		account2.setNumber(987654321);
		account2.setPerson(person);
		
		Account account3 = new Account();
		account3.setBankName("SBI");
		account3.setNumber(753198246);
		account3.setPerson(person);
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("simha");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		
		em.persist(person);
		em.persist(account1);
		em.persist(account2);
		em.persist(account3);
		
		et.commit();
	}

}
