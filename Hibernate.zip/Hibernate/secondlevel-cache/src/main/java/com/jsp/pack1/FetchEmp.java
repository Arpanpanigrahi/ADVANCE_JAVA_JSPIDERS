package com.jsp.pack1;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class FetchEmp {
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("simha");
		EntityManager entityManager1 = entityManagerFactory.createEntityManager();
		EntityManager entityManager2 = entityManagerFactory.createEntityManager();
		Employee e1 = entityManager1.find(Employee.class, 1);
		Employee e2 = entityManager1.find(Employee.class, 1);
		Employee e3 = entityManager2.find(Employee.class, 1);
		
		EntityManager entityManager3 = entityManagerFactory.createEntityManager();
		entityManager3.find(Employee.class, 1);
	}
}