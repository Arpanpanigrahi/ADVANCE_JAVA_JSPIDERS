package com.jsp.driver;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.jsp.entities.Identity;
import com.jsp.entities.Person;

public class Test1 {
	public static void main(String[] args) {
		Person person = new Person();
		person.setName("Arpan");
		person.setAge(23);
		person.setLoc("Mumbai");
		
		Identity identity = new Identity();
		identity.setName("Aadhar");
		identity.setNumber(123456789);
		
		person.setIdentity(identity);
		identity.setPerson(person);
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("simha");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
		entityManager.persist(person);
		entityManager.persist(identity);
		entityTransaction.commit();
	}
}
