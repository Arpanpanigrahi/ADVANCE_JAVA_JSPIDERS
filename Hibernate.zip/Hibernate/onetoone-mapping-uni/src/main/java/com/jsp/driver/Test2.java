package com.jsp.driver;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.jsp.entities.Identity;
import com.jsp.entities.Person;

public class Test2 {
	public static void main(String[] args) {
		Person person = new Person();
		person.setName("rahul");
		person.setLoc("Bangalore");
		person.setAge(26);
		
		Identity ide = new Identity();
		ide.setName("PAN Card");
		ide.setNumber("ckzpn3380h");
		person.setIde(ide);
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("simha");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
		entityManager.persist(person);
		entityManager.persist(ide);
		entityTransaction.commit();
		
	}

}
