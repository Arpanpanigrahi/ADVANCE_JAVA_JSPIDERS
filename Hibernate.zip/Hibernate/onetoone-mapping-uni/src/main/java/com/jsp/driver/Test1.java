package com.jsp.driver;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.jsp.entities.Company;
import com.jsp.entities.GST;

public class Test1 {
	public static void main(String[] args) {
		Company c = new Company();
		c.setName("Amazon");
		c.setAddress("Bangalore");
		c.setNoOfEmployee(20998764);
		
		GST gst = new GST();
		gst.setNumber("2345");
		gst.setCost(20000);
		c.setGst(gst);
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("simha");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
		entityManager.persist(c);
		entityManager.persist(gst);
		entityTransaction.commit();
	}
}
