package com.jsp.driver;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.jsp.entities.Student;
import com.jsp.entities.Subject;

public class Test {
	public static void main(String[] args) {
		List<Subject> subjects = new ArrayList<Subject>();
		List<Student> students = new ArrayList<Student>();
		
		Subject subject1 = new Subject();
		subject1.setName("Java");
		subject1.setDuration(90);
		subject1.setTrainerName("Raveesh");
		
		Subject subject2 = new Subject();
		subject2.setName("Web_Dev");
		subject2.setDuration(45);
		subject2.setTrainerName("Kishore");
		
		subjects.add(subject1);
		subjects.add(subject2);
		
		Student student1 = new Student();
		student1.setName("Akash");
		student1.setAge(21);
		
		Student student2 = new Student();
		student2.setName("Mohit");
		student2.setAge(21);
		
		students.add(student1);
		students.add(student2);
		
		student1.setList(subjects);
		student2.setList(subjects);
		
		subject1.setList(students);
		subject2.setList(students);
		
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("simha");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
		entityManager.persist(student1);
		entityManager.persist(student2);
		entityManager.persist(subject1);
		entityManager.persist(subject2);
		entityTransaction.commit();	
		
	}
}
