import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
@WebServlet("/reg")
public class SaveRegistration extends HttpServlet{
	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name = req.getParameter("n");
		int age = Integer.parseInt(req.getParameter("a"));
		String gender = req.getParameter("g");
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/servlet_001?user=root&password=Arpan@7219193146");
			String sql = "INSERT INTO register(name , age , gender) values(? , ? , ?)" ;
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, name);
			ps.setInt(2, age);
			ps.setString(3, gender);
			ps.execute();
			con.close();
		}catch(Exception e) {
			//e.printStackTrace();
			System.out.println("JDBC issue");
		}
	}

}
