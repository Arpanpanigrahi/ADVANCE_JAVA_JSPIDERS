package dispatcherServlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class LoginServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String email = req.getParameter("e");
		String psw = req.getParameter("p");
		
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		
//		RequestDispatcher dispatcher = req.getRequestDispatcher("Login.html");
		
		if(email.equals("abc@gmail.com") && psw.equals("123456")) {
			RequestDispatcher dispatcher = req.getRequestDispatcher("Home.html");
			dispatcher.forward(req, res);
		}
		else {
//			out.println("<h3> Invalid Username or Password </h3>");
			RequestDispatcher dispatcher = req.getRequestDispatcher("Login.html");
			dispatcher.include(req, res);
			out.println("<h3> Invalid Username or Password </h3>");
		}
	}
}
