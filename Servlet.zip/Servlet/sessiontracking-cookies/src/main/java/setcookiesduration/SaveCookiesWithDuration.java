package setcookiesduration;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/setcookieage")
public class SaveCookiesWithDuration extends HttpServlet{
	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		Cookie cookie1 = new Cookie("name","linga");
		Cookie cookie2 = new Cookie("age", "10");
		Cookie cookie3 = new Cookie("password", "dingi");
		
		cookie1.setMaxAge(10000);
		cookie2.setMaxAge(100000);
		cookie3.setMaxAge(100000);
		
		res.addCookie(cookie1);
		res.addCookie(cookie2);
		res.addCookie(cookie3);
	}
}
