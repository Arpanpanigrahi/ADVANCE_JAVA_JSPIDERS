package com.jsp.sessiontracking;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/savecookies")
public class SaveCookies extends HttpServlet{
	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		
		Cookie cookie = new Cookie("name", "Arpan"); //we store information in the form of key and value pair.
		Cookie cookie1 = new Cookie("useremail", email);
		Cookie cookie2 = new Cookie("password", password);
		
		res.addCookie(cookie); // addCookie() carries the cookies to the browser and saves the cookie inside the browser.
		res.addCookie(cookie1);
		res.addCookie(cookie2);
		
		PrintWriter pw = res.getWriter();
		pw.print("<h1> cookies are saved successfully </h1>");
	}
	
}
