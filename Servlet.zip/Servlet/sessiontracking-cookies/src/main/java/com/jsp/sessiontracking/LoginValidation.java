package com.jsp.sessiontracking;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/loginvalidate")
public class LoginValidation extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		
		if(email.equals("dinga@gmail.com") && password.equals("123")) {
			Cookie cookie1 = new Cookie("email", email);
			Cookie cookie2 = new Cookie("password", password);
			
			cookie1.setMaxAge(100000);
			cookie2.setMaxAge(100000);
			
			res.addCookie(cookie2);
			res.addCookie(cookie1);
			
			RequestDispatcher rd = req.getRequestDispatcher("welcome.html");
			rd.include(req, res);
		}
		else
		{
			res.getWriter().println("<h1> Invalid UserName or Password Enter Once Again to Validate </h1>");
			RequestDispatcher rd = req.getRequestDispatcher("Loginform.html");
			rd.include(req, res);
		}
	}
}