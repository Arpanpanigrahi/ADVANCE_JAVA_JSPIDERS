package demo1.package1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class Servlet2 extends GenericServlet{

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		String name = req.getParameter("name");
		String age = req.getParameter("age");
		
//		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		out.println(age);
		out.println("<h1>"+name+"</h1>");
		Class.forName("com.mysql.cj.jdbc.Driver");
//		out.println(age);
	}

}
