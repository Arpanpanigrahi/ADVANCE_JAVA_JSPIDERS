package com.httpsession;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/save")
public class SaveData extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		HttpSession session1 = req.getSession();
		HttpSession session2 = req.getSession();
		
//		System.out.println(session1);
//		System.out.println(session2);
		
		session1.setAttribute("name", "Rajesh");
		session1.setAttribute("age", 23);
		session1.setAttribute("male", true);
		
//		System.out.println(session2.getAttribute("name"));       //Rajesh
//		System.out.println(session2.getAttribute("age"));		 //23
//		System.out.println(session2.getAttribute("male"));		 //true
//		System.out.println(session2.getAttribute("mobilenum"));  //null
		
		session1.removeAttribute("name");
		
		session1.invalidate();
		
		System.out.println(session1.getAttribute("age"));
	}
}
