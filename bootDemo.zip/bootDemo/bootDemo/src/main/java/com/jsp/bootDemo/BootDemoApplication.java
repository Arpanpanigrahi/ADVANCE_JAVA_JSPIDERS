package com.jsp.bootDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;


//@SpringBootApplication
@SpringBootApplication(scanBasePackages = "com.jsp.bootDemo.controller") //specifying the package name of our rest controller class to spring boot 
@EnableJpaRepositories(basePackages = "com.jsp.bootDemo.repository") //specifying the package name of repositories to spring boot
@EntityScan(basePackages = "com.jsp.bootDemo.dto")  //specifying the location (package name) of our entity classes to spring boot
public class BootDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootDemoApplication.class, args);
	}

}
