package com.jsp.bootDemo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsp.bootDemo.dto.Student;

public interface StudentRepository extends JpaRepository<Student, Integer> {

	List<Student> findByName(String name);

	List<Student> findByAgeGreaterThan(int age);
	
	List<Student> findByAgeLessThan(int age);
	
	Student findByMobilenumber(long mobilenumber);

	List<Student> findByAgeBetween(int age1, int age2);
	
	Student findByNameAndMobilenumber(String name, long mobilenumber);

}




/*
 * package com.jsp.bootDemo.repository;
 * 
 * import java.util.List;
 * 
 * import com.jsp.bootDemo.dto.Student;
 * 
 * public class StudentRepository extends JPARepository<Student, Integer> {
 * List<Student> findByName(String name);
 * 
 * List<Student> findByAgeGreaterThan(int age);
 * 
 * List<Student> findByAgeLessThan(int age);
 * 
 * Student findByMobilenumber(long mobilenumber);
 * 
 * List<Student> findByAgeBetween(int start, int end);
 * 
 * Student findByNameAndMobilenumber(String name, long mobilenumber);
 * 
 * }
 */
