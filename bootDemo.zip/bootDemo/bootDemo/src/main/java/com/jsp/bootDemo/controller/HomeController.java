package com.jsp.bootDemo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.bootDemo.dto.Student;
import com.jsp.bootDemo.repository.StudentRepository;

@RestController
public class HomeController {

	@Autowired
	StudentRepository repository;

	@PostMapping("/hi")
	public String m1() {
		return "hello world";
	}

	@PostMapping("/save")
	public String saveStudent(@RequestBody Student student) {
		repository.save(student);
		return "data saved";
	}

	@GetMapping("/fetchstudent")
	public Student fetchStudent(@RequestParam("id") int id) {
		Optional<Student> option = repository.findById(id);
		Student student = option.get();
		return student;
	}

	@GetMapping("/fetchstudentbyname")
	public List<Student> fetchStudentByName(@RequestParam("name") String name) {
		return repository.findByName(name);
	}

	@GetMapping("/fetchstudentbyagegreater")
	public List<Student> fetchStudentByAgeGreat(@RequestParam("age") int age) {
		return repository.findByAgeGreaterThan(age);
	}

	@GetMapping("/fetchstudentagebetween")
	public List<Student> fetchStudentBetween(@RequestParam("start") int age1, @RequestParam("end") int age2) {
		return repository.findByAgeBetween(age1, age2);
	}
}
