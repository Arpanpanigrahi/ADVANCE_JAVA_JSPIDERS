package com.jsp.bootdemo.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.jsp.bootdemo.helper.ResponceStructure;

@RestControllerAdvice
public class HandlingException {
	@ExceptionHandler(value = StudentNotFoundException.class)
	public ResponceStructure<StudentNotFoundException>m1(StudentNotFoundException s){
		ResponceStructure<StudentNotFoundException> response= new ResponceStructure<StudentNotFoundException>();
		response.setStstuscode(HttpStatus.NOT_FOUND.value());
		response.setMessage(s.getMessage());
		response.setData(s);
		return response;
	}

}