package com.jsp.bootdemo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.bootdemo.dto.Student;
import com.jsp.bootdemo.exception.StudentNotFoundException;
import com.jsp.bootdemo.helper.ResponceStructure;
import com.jsp.bootdemo.repository.StudentRepository;

@RestController  //@controller and @responsebody(converts java object to json)
public class HomeController {
	
	@Autowired
	StudentRepository repository;
	
	@PostMapping("/hi")
	public String m1() {
		return "hello world";
	}
	
	@PostMapping("/save")
	public String saveStudent(@RequestBody Student student) {
		repository.save(student);
		return "data saved";
	}
	
	@GetMapping("/fetchstudent")
	public ResponceStructure<Student> fetchStudent(@RequestParam("id") int id) {
		
	Optional<Student>option=repository.findById(id);
	if(option.isPresent()) {	//Exception handling
		Student student = option.get();
		ResponceStructure<Student> response= new ResponceStructure<Student>();
		response.setStstuscode(HttpStatus.FOUND.value());
		response.setMessage("data found successfully");
		response.setData(student);
		return response;
	}
	else {
		throw new StudentNotFoundException("Student  not found");
	}
	
	}
	
	@GetMapping("/fetchstudentbyname")
	public ResponceStructure<List<Student>> fetchStudentByName(@RequestParam("name") String name) {
		List<Student> ls= repository.findByName(name);
		
		if(ls.isEmpty()) {
			throw new StudentNotFoundException("Student  not found");

			
		}
		else {
			ResponceStructure<List<Student>> response= new ResponceStructure<List<Student>>();
			response.setStstuscode(HttpStatus.FOUND.value());
			response.setMessage("data found successfully");
			response.setData(ls);
			return response;
		}

		
	}
	
	@GetMapping("/fetchstudentbyagegreater")
	public List <Student> fetchStudentByAgeGreaterThan(@RequestParam("age") int age) {
	return repository.findByAgeGreaterThan(age);
	}
	
	@GetMapping("/fetchstudentbyageless")
	public List <Student> fetchStudentByAgeLessThan(@RequestParam("age") int age) {
	return repository.findByAgeLessThan(age);
	}
	
}