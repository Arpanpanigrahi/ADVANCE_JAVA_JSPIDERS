package com.jsp.bootdemo.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.bootdemo.dto.User;
import com.jsp.bootdemo.exception.UserNotFoundException;
import com.jsp.bootdemo.helper.Login;
import com.jsp.bootdemo.helper.ResponceStructure;
import com.jsp.bootdemo.repository.UserRepository;

@RestController
public class UserController {
	
	@Autowired
	UserRepository repository;
	
	@PostMapping("/saveuser")
	public ResponceStructure<User> saveUser(@RequestBody User user){
		repository.save(user);
		ResponceStructure<User> responce = new ResponceStructure<User>();
		responce.setStstuscode(HttpStatus.CREATED.value());
		responce.setMessage("data saved successfully");
		responce.setData(user);
		return responce;
	}
	
	@GetMapping("/loginvalidation")
	public ResponceStructure<User> loginUser(@RequestBody Login l){
		User user = repository.findByEmailAndPassword(l.getEmail(), l.getPassword());
		if(user!=null) {
			ResponceStructure<User> responce = new ResponceStructure<User>();
			responce.setStstuscode(HttpStatus.FOUND.value());
			responce.setMessage("data found");
			responce.setData(user);
			return responce;
		}else {
			throw new UserNotFoundException("user not found");
		}
	}
	@DeleteMapping("/deleteuser")
	public ResponceStructure<String> deleteUser(@RequestParam("id") int id){
		repository.deleteById(id);
	    ResponceStructure<String> responce = new ResponceStructure<String>();
	    responce.setStstuscode(HttpStatus.OK.value());
	    responce.setMessage("data deleted");
	     return responce;
	} 
	@PutMapping("/update")
	public ResponceStructure<User> updateUser(@RequestBody User u){
		repository.save(u);
		ResponceStructure<User> responce = new ResponceStructure<User>();
		responce.setMessage("data updated");
		responce.setData(u);
		responce.setStstuscode(HttpStatus.ACCEPTED.value());
		return responce;
	}
	@PatchMapping("/patchreq")
	public ResponceStructure<User> patchUser(@RequestParam("name") String name, @RequestParam("id") int id){
		Optional<User> option = repository.findById(id);
		User user = option.get();
		user.setName(name);
		repository.save(user);
		
		ResponceStructure<User> responce = new ResponceStructure<User>();
		responce.setMessage("data updated");
		responce.setData(user);
		responce.setStstuscode(HttpStatus.ACCEPTED.value());
		return responce;
	}
}	
